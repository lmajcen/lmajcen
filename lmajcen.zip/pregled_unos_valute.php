<?php
    include("baza_podataka.php");
    session_start();
    if (isset($_SESSION['uloga'])) {
        if ($_SESSION['uloga'] == 1 || $_SESSION['uloga'] == 0) {
            $korisnikId = $_SESSION['korisnikId'];
        }
        else header('Location: prijava_dizajn.php');
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Mjenjačnica HARON</title>
        <link rel="stylesheet" href="./css/style.css">
    </head>
    <body>
        <header>
            <div class="container">
                <div id= "naslovnica">
                    <h1>Mjenjačnica <span class="highlight">HARON</span></h1>
                    <nav>
                    <ul>
                        <li><a href="index.php">Početna</a></li>
                        <li><a href="usluga.php">Usluga</a></li>
                        <li><a href="o_autoru.html">O autoru</a></li>
                        <li><a href="odjava.php">Odjava</a></li>
                     </ul>
                    </nav>
                </div>
            </div>

            <div class="container">
                <div id= "MeniRegistriraniKorisnik">
                <nav>
                    <ul>
                        <li><a href="vrijednosti_valuta.php">Vrijednosti valuta</a></li>
                        <li><a href="raspoloziva_sredstva_zahtjevi.php">Raspoloživa sredstva i zahtjevi</a></li>
                        <?php 
                        if ($_SESSION["uloga"] == 0 || $_SESSION["uloga"] == 1) {
                            echo '
                                <li><a href="odobri_zahtjev.php">Odobravanje zahtjeva</a></li>
                                <li><a href="azuriraj_valute.php">Ažuriranje valute</a></li>
                            ';
                        }
                        if ($_SESSION["uloga"] == 0) {
                            echo '
                            <li><a href="korisnici.php">Korisnici</a></li>
                            <li><a href="pregled_unos_valute.php">Pregled i unos valute</a></li>
                            <li><a href="prodaja.php">Prodaja</a></li>
                            ';
                        }
                            ?>
                     </ul>
                    </nav>
                </div>
            </div>
        </header>
        
        <section id="PopisValuta">
        <div class="container">
                <table>
                    <thead>
                        <tr>
                            <th> Naziv </th>
                            <th> Tečaj </th>
                            <th> Moderator </th>
                            <th> Aktivno od </th>
                            <th> Aktivno do </th>
                            <th> Datum ažuriranja </th>
                        </tr>
                    </thead>
                    <?php
                        $upit = "SELECT naziv, tecaj, moderator_id, aktivno_od, aktivno_do, datum_azuriranja FROM valuta";

                        $rezultat = mysqli_query($spojka,$upit);
                        while($row = mysqli_fetch_array($rezultat))
                        {
                    ?>
                            <tr>
                                <td> <?php echo $row [0]; ?> </td>
                                <td> <?php echo $row [1]; ?> </td>
                                <td> <?php echo $row [2]; ?> </td>
                                <td> <?php echo $row [3]; ?> </td>
                                <td> <?php echo $row [4]; ?> </td>
                                <td> <?php echo $row [5]; ?> </td>
                            </tr>
                        <?php
                        } 
                        ?> 
                </table>
        </div>
        </section>

        <section id="UnesiValutu">
            <div class="box">
                <h1> Unesi valutu: </h1>
                <form method="POST">

                    <label for="Naziv">Naziv:</label><br>
                    <input type="text" id="Naziv" placeholder="Unesi!" required name="nazivValute"><br>
                    <label for="Tečaj">Tečaj:</label><br>
                    <input type="text" id="Tečaj" placeholder="Unesi!" required name="tecaj"><br>
                    <label for="Aktivno od">Aktivno od:</label><br>
                    <input type="text" id="AktivnoOd" placeholder="Sati-Minute-Sekunde" required name="aktivnoOd"><br>
                    <label for="Aktivno do">Aktivno do:</label><br>
                    <input type="text" id="AktivnoDo" placeholder="Sati-Minute-Sekunde" required name="aktivnoDo"><br>
                    <label for="Slika:">Slika:</label><br>
                    <input type="text" id="Slika" placeholder="Unesi!" required name="slika"><br>
                    <label for="Zvuk">Zvuk:</label><br>
                    <input type="text" id="Zvuk" placeholder="Unesi!" name="zvuk"><br>
                    <br>

                    <select name="nazivModeratora">
                    <?php
                    $upit = "SELECT korisnicko_ime, korisnik_id FROM korisnik WHERE tip_korisnika_id = 1";
                    $rezultat = mysqli_query($spojka, $upit);
                    while($row = mysqli_fetch_array($rezultat))
                    {
                    ?>
                    <option value="<?php echo $row[1]; ?>"><?php echo $row[0]; ?></option>;
                    <?php
                    }
                    ?>
                    
                    </select>

                    <br>
                    <input type="submit" value="Unesi valutu!" name="submit-add-valuta" class="submit-amount"></input>
                </form>
                <?php 
                    if (isset($_POST["submit-add-valuta"])) {

                        $nazivValute = $_POST["nazivValute"];
                        $tecaj = $_POST["tecaj"];
                        $aktivnoOd = $_POST["aktivnoOd"];
                        $aktivnoDo = $_POST["aktivnoDo"];
                        $slika = $_POST["slika"];
                        $zvuk = $_POST["zvuk"];
                        $nazivModeratora = $_POST["nazivModeratora"];
                        
                        $insert = "INSERT INTO `valuta`(`valuta_id`, `moderator_id`, `naziv`, `tecaj`, `slika`, `zvuk`, `aktivno_od`, `aktivno_do`, `datum_azuriranja`) VALUES (NULL, '$nazivModeratora', '$nazivValute', $tecaj, '$slika', '$zvuk', '$aktivnoOd', '$aktivnoDo', NOW())";
                        $rezultat = mysqli_query($spojka, $insert);
                    }
                ?>
            </div>
        </section>
        <section id="azurirajValutu">
            <div class="box">
                <h1>Ažuriraj valutu</h1>
                <form action="" method="POST">
                    
                    <label for="selectValuta">Odaberite valutu: </label><br>
                    <select id="selectValuta" name="valutaId">
                    <?php
                
                    $upit = "SELECT valuta_id, naziv FROM valuta";
                    $rezultat = mysqli_query($spojka, $upit);
                    while($row = mysqli_fetch_array($rezultat))
                    {
                    ?>
                    <option value="<?php echo $row[0]; ?>"><?php echo $row["naziv"]; ?></option>
                    <?php
                    }
                    ?>
                    </select><br>

                    <label for="valutaChange">Odaberite promjenu:  </label><br>
                    <select id="valutaChange" name="valutaChange">
                        <?php
                    
                            $upit = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'valuta' AND COLUMN_NAME NOT IN ('valuta_id')";
                            $rezultat = mysqli_query($spojka, $upit);
                            while($row = mysqli_fetch_array($rezultat))
                            {
                        ?>
                                <option value="<?php echo $row[0]; ?>"><?php echo $row[0]; ?></option>
                        <?php
                            }
                        ?>

                    </select><br>
                        <label for="unesiPromjenu">Unesi promjenu: </label><br>
                        <input type="text" id="unesiPromjenu" placeholder="Unesi!" name="valutaPromjena"><br>
                        <input type="submit" value="Ažuriraj valutu!" name="submitvaluta" class="submit-amount"></input>
                </form>
            </div>

            <?php
                    
                    if (isset($_POST["submitvaluta"])) {
                        $valutaID = $_POST["valutaId"];
                        $promjena = $_POST["valutaChange"];
                        $novaVrijednost = $_POST["valutaPromjena"];


                        $update = "UPDATE `valuta` SET `$promjena` = '$novaVrijednost' WHERE valuta_id = $valutaID";
                        $rezultat = mysqli_query($spojka, $update);
                    }
                ?>

        </section>









    
                   
                    